"use client"

import { useState, useEffect, useCallback } from "react"
import { Activity, RefreshCw } from "lucide-react"
import { CountdownTimer } from "@/components/countdown-timer"
import { StatsCards } from "@/components/stats-cards"
import { ComunaChart } from "@/components/comuna-chart"
import { HourlyChart } from "@/components/hourly-chart"
import { PuestoTable } from "@/components/puesto-table"
import { MesaTable } from "@/components/mesa-table"
import { RecentVoters } from "@/components/recent-voters"
import { VotingProgress } from "@/components/voting-progress"
import {
  voterData,
  totalRegisteredVoters,
  comunasData,
  puestosData,
  metaVotosPorMesa,
  getHourlyRegistrations,
  generateSimulatedVoters,
  type Voter,
  type ComunaData,
  type PuestoData,
} from "@/lib/voter-data"

// Polls close at 4:00 PM today
function getClosingTime(): Date {
  const today = new Date()
  today.setHours(16, 0, 0, 0)
  return today
}

export default function Dashboard() {
  const [voters, setVoters] = useState<Voter[]>([])
  const [comunas, setComunas] = useState<ComunaData[]>(comunasData)
  const [puestos, setPuestos] = useState<PuestoData[]>(puestosData)
  const [isLive, setIsLive] = useState(true)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Initialize with simulated data on mount
  useEffect(() => {
    const simulated = generateSimulatedVoters(voterData, 180)
    setVoters(simulated)
    recalculateStats(simulated)
  }, [])

  const recalculateStats = useCallback((currentVoters: Voter[]) => {
    // Recalculate comunas
    const comunaCounts: Record<number, number> = {}
    currentVoters.forEach((v) => {
      if (v.voto) {
        comunaCounts[v.comuna] = (comunaCounts[v.comuna] || 0) + 1
      }
    })
    setComunas(
      comunasData.map((c) => ({
        ...c,
        votantes: comunaCounts[c.comuna] || 0,
      }))
    )

    // Recalculate puestos
    const puestoCounts: Record<string, number> = {}
    currentVoters.forEach((v) => {
      if (v.voto) {
        puestoCounts[v.puestoVotacion] = (puestoCounts[v.puestoVotacion] || 0) + 1
      }
    })
    setPuestos(
      puestosData.map((p) => ({
        ...p,
        votantes: puestoCounts[p.puesto] || 0,
      }))
    )
  }, [])

  // Simulate new voters arriving every few seconds for real-time feel
  useEffect(() => {
    if (!isLive) return

    const interval = setInterval(() => {
      setVoters((prev) => {
        const nombres = [
          "CARLOS MARTINEZ", "MARIA LOPEZ", "ANDRES RUIZ",
          "PATRICIA GOMEZ", "LUIS DIAZ", "CARMEN VILLAMIZAR",
          "PEDRO SUAREZ", "ROSA CONTRERAS", "MIGUEL ORTEGA",
          "SANDRA PENA", "BEATRIZ MORA", "FERNANDO PLATA",
        ]
        const puestosArr = puestosData
        const puesto = puestosArr[Math.floor(Math.random() * puestosArr.length)]
        const comunas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        const lideres = ["ADRIANA", "BLANCA", "CARLOS", "DIANA", "ELENA"]
        const now = new Date()

        const newVoter: Voter = {
          id: prev.length + 1,
          lider: lideres[Math.floor(Math.random() * lideres.length)],
          nombre: nombres[Math.floor(Math.random() * nombres.length)],
          cedula: String(10000000 + Math.floor(Math.random() * 90000000)),
          municipio: puesto.municipio,
          puestoVotacion: puesto.puesto,
          direccion: "",
          mesa: puesto.mesas[Math.floor(Math.random() * puesto.mesas.length)],
          comuna: comunas[Math.floor(Math.random() * comunas.length)],
          voto: true,
          horaRegistro: now,
        }

        const updated = [...prev, newVoter]
        recalculateStats(updated)
        setLastUpdate(new Date())
        return updated
      })
    }, 4000)

    return () => clearInterval(interval)
  }, [isLive, recalculateStats])

  const totalVoted = voters.filter((v) => v.voto).length
  const votingPercentage = totalRegisteredVoters > 0 ? (totalVoted / totalRegisteredVoters) * 100 : 0
  const hourlyData = getHourlyRegistrations(voters)

  // Calculate last hour registrations
  const now = new Date()
  const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000)
  const registrosUltimaHora = voters.filter(
    (v) => v.voto && v.horaRegistro >= oneHourAgo
  ).length

  // Build mesa data
  const mesaCounts: Record<number, { votantes: number; puesto: string }> = {}
  voters.forEach((v) => {
    if (v.voto) {
      if (!mesaCounts[v.mesa]) {
        mesaCounts[v.mesa] = { votantes: 0, puesto: v.puestoVotacion }
      }
      mesaCounts[v.mesa].votantes += 1
    }
  })
  const mesaData = Object.entries(mesaCounts).map(([mesa, info]) => ({
    mesa: Number(mesa),
    votantes: info.votantes,
    meta: metaVotosPorMesa[Number(mesa)] || 40,
    puesto: info.puesto,
  }))

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-[1600px] items-center justify-between px-4 py-3 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
              <Activity className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-card-foreground leading-tight">Centro de Comando Electoral</h1>
              <p className="text-xs text-muted-foreground">Monitoreo en tiempo real de la jornada electoral</p>
            </div>
          </div>

          <div className="hidden md:block">
            <CountdownTimer closingTime={getClosingTime()} />
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsLive(!isLive)}
              className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                isLive
                  ? "bg-primary/10 text-primary"
                  : "bg-secondary text-muted-foreground"
              }`}
            >
              <span className={`h-2 w-2 rounded-full ${isLive ? "bg-primary animate-pulse" : "bg-muted-foreground"}`} />
              {isLive ? "EN VIVO" : "PAUSADO"}
            </button>
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <RefreshCw className="h-3 w-3" />
              <span className="tabular-nums">
                {lastUpdate.toLocaleTimeString("es-CO", {
                  hour: "2-digit",
                  minute: "2-digit",
                  second: "2-digit",
                })}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Countdown */}
      <div className="block md:hidden border-b border-border bg-card px-4 py-3">
        <CountdownTimer closingTime={getClosingTime()} />
      </div>

      {/* Dashboard Content */}
      <main className="mx-auto max-w-[1600px] flex flex-col gap-6 px-4 py-6 lg:px-8">
        {/* Stats Row */}
        <StatsCards
          totalRegistered={totalRegisteredVoters}
          totalVoted={totalVoted}
          votingPercentage={votingPercentage}
          registrosUltimaHora={registrosUltimaHora}
        />

        {/* Charts Row */}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <ComunaChart data={comunas} />
          </div>
          <VotingProgress totalRegistered={totalRegisteredVoters} totalVoted={totalVoted} />
        </div>

        {/* Hourly + Puestos */}
        <div className="grid gap-6 lg:grid-cols-2">
          <HourlyChart data={hourlyData} />
          <PuestoTable data={puestos} />
        </div>

        {/* Mesa + Recent Voters */}
        <div className="grid gap-6 lg:grid-cols-2">
          <MesaTable data={mesaData} />
          <RecentVoters voters={voters} />
        </div>

        {/* Footer */}
        <footer className="border-t border-border py-4 text-center text-xs text-muted-foreground">
          Centro de Comando Electoral &middot; Datos actualizados en tiempo real &middot; Jornada Electoral 2026
        </footer>
      </main>
    </div>
  )
}
