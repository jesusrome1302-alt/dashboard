"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts"
import type { ComunaData } from "@/lib/voter-data"

interface ComunaChartProps {
  data: ComunaData[]
}

export function ComunaChart({ data }: ComunaChartProps) {
  const chartData = data
    .filter((c) => c.votantes > 0 || c.meta > 0)
    .map((c) => ({
      name: `C${c.comuna}`,
      fullName: c.nombre,
      votantes: c.votantes,
      meta: c.meta,
      pct: c.meta > 0 ? Math.round((c.votantes / c.meta) * 100) : 0,
    }))
    .sort((a, b) => b.pct - a.pct)

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
          Avance por Comuna
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(260 10% 25%)" />
              <XAxis
                dataKey="name"
                tick={{ fill: "hsl(0 0% 65%)", fontSize: 11 }}
                axisLine={{ stroke: "hsl(260 10% 25%)" }}
              />
              <YAxis
                tick={{ fill: "hsl(0 0% 65%)", fontSize: 11 }}
                axisLine={{ stroke: "hsl(260 10% 25%)" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(260 10% 17%)",
                  border: "1px solid hsl(260 10% 28%)",
                  borderRadius: "8px",
                  color: "hsl(0 0% 95%)",
                }}
                formatter={(value: number, name: string) => {
                  if (name === "votantes") return [value, "Votos registrados"]
                  return [value, "Meta"]
                }}
                labelFormatter={(label) => {
                  const item = chartData.find((d) => d.name === label)
                  return item?.fullName || label
                }}
              />
              <Bar dataKey="meta" fill="hsl(260 10% 25%)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="votantes" radius={[4, 4, 0, 0]}>
                {chartData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.pct >= 50 ? "hsl(145 60% 45%)" : entry.pct >= 25 ? "hsl(55 70% 55%)" : "hsl(25 80% 50%)"}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
