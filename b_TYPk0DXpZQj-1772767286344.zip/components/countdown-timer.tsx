"use client"

import { useState, useEffect } from "react"
import { Timer } from "lucide-react"

interface CountdownTimerProps {
  closingTime: Date
}

export function CountdownTimer({ closingTime }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({ hours: 0, minutes: 0, seconds: 0, expired: false })

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date()
      const diff = closingTime.getTime() - now.getTime()

      if (diff <= 0) {
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0, expired: true })
        clearInterval(interval)
        return
      }

      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)

      setTimeLeft({ hours, minutes, seconds, expired: false })
    }, 1000)

    return () => clearInterval(interval)
  }, [closingTime])

  const urgency = timeLeft.hours < 1 ? "text-destructive" : timeLeft.hours < 3 ? "text-accent" : "text-primary"

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Timer className="h-4 w-4" />
        <span className="text-sm font-medium uppercase tracking-wider">Cierre de Urnas</span>
      </div>
      {timeLeft.expired ? (
        <div className="text-destructive text-2xl font-bold uppercase tracking-widest">
          Urnas Cerradas
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <TimeBlock value={timeLeft.hours} label="Horas" urgency={urgency} />
          <span className={`text-3xl font-bold ${urgency}`}>:</span>
          <TimeBlock value={timeLeft.minutes} label="Min" urgency={urgency} />
          <span className={`text-3xl font-bold ${urgency}`}>:</span>
          <TimeBlock value={timeLeft.seconds} label="Seg" urgency={urgency} />
        </div>
      )}
    </div>
  )
}

function TimeBlock({ value, label, urgency }: { value: number; label: string; urgency: string }) {
  return (
    <div className="flex flex-col items-center">
      <span className={`text-4xl font-mono font-bold tabular-nums ${urgency}`}>
        {String(value).padStart(2, "0")}
      </span>
      <span className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</span>
    </div>
  )
}
