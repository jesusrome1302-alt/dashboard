"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import type { HourlyData } from "@/lib/voter-data"

interface HourlyChartProps {
  data: HourlyData[]
}

export function HourlyChart({ data }: HourlyChartProps) {
  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
          Ritmo de Registros por Hora
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
              <defs>
                <linearGradient id="colorRegistros" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(145 60% 45%)" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="hsl(145 60% 45%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(260 10% 25%)" />
              <XAxis
                dataKey="hora"
                tick={{ fill: "hsl(0 0% 65%)", fontSize: 11 }}
                axisLine={{ stroke: "hsl(260 10% 25%)" }}
              />
              <YAxis
                tick={{ fill: "hsl(0 0% 65%)", fontSize: 11 }}
                axisLine={{ stroke: "hsl(260 10% 25%)" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(260 10% 17%)",
                  border: "1px solid hsl(260 10% 28%)",
                  borderRadius: "8px",
                  color: "hsl(0 0% 95%)",
                }}
                formatter={(value: number) => [value, "Registros"]}
              />
              <Area
                type="monotone"
                dataKey="registros"
                stroke="hsl(145 60% 45%)"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorRegistros)"
                dot={{ fill: "hsl(145 60% 45%)", r: 4 }}
                activeDot={{ r: 6, strokeWidth: 2 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
