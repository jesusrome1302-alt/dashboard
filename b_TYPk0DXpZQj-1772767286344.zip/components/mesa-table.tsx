"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { CheckCircle, AlertTriangle } from "lucide-react"

interface MesaTableProps {
  data: { mesa: number; votantes: number; meta: number; puesto: string }[]
}

export function MesaTable({ data }: MesaTableProps) {
  const sorted = [...data].sort((a, b) => {
    const pctA = a.meta > 0 ? a.votantes / a.meta : 0
    const pctB = b.meta > 0 ? b.votantes / b.meta : 0
    return pctA - pctB
  })

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
          Cumplimiento por Mesa vs Meta
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[380px]">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="px-4 py-2 text-left text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                  Mesa
                </th>
                <th className="px-4 py-2 text-left text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                  Puesto
                </th>
                <th className="px-4 py-2 text-center text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                  Votos
                </th>
                <th className="px-4 py-2 text-center text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                  Meta
                </th>
                <th className="px-4 py-2 text-right text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                  Avance
                </th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((mesa, idx) => {
                const pct = mesa.meta > 0 ? (mesa.votantes / mesa.meta) * 100 : 0
                const isLow = pct < 15

                return (
                  <tr key={idx} className={`border-b border-border ${isLow ? "bg-destructive/5" : ""}`}>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        {isLow ? (
                          <AlertTriangle className="h-3 w-3 text-destructive" />
                        ) : (
                          <CheckCircle className="h-3 w-3 text-primary" />
                        )}
                        <span className="text-sm font-mono font-medium text-card-foreground">
                          #{mesa.mesa}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className="text-xs text-muted-foreground truncate block max-w-[150px]">
                        {mesa.puesto}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      <span className="text-sm font-bold tabular-nums text-card-foreground">{mesa.votantes}</span>
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      <span className="text-sm tabular-nums text-muted-foreground">{mesa.meta}</span>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center justify-end gap-2">
                        <div className="h-1.5 w-16 rounded-full bg-secondary">
                          <div
                            className={`h-1.5 rounded-full transition-all duration-700 ease-out ${
                              isLow ? "bg-destructive" : pct >= 30 ? "bg-primary" : "bg-accent"
                            }`}
                            style={{ width: `${Math.min(pct, 100)}%` }}
                          />
                        </div>
                        <span className={`text-xs font-bold tabular-nums w-10 text-right ${
                          isLow ? "text-destructive" : pct >= 30 ? "text-primary" : "text-accent"
                        }`}>
                          {pct.toFixed(0)}%
                        </span>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
