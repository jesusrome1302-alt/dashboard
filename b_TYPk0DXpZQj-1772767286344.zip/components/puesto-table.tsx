"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MapPin, AlertTriangle, CheckCircle } from "lucide-react"
import type { PuestoData } from "@/lib/voter-data"

interface PuestoTableProps {
  data: PuestoData[]
}

export function PuestoTable({ data }: PuestoTableProps) {
  const sorted = [...data].sort((a, b) => {
    const pctA = a.meta > 0 ? a.votantes / a.meta : 0
    const pctB = b.meta > 0 ? b.votantes / b.meta : 0
    return pctA - pctB
  })

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
          Avance por Punto de Votacion
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[380px]">
          <div className="flex flex-col">
            {sorted.map((puesto, idx) => {
              const pct = puesto.meta > 0 ? (puesto.votantes / puesto.meta) * 100 : 0
              const isLow = pct < 15
              const isOk = pct >= 30

              return (
                <div
                  key={idx}
                  className={`flex items-center gap-3 border-b border-border px-4 py-3 ${
                    isLow ? "bg-destructive/5" : ""
                  }`}
                >
                  <div className="flex-shrink-0">
                    {isLow ? (
                      <AlertTriangle className="h-4 w-4 text-destructive" />
                    ) : isOk ? (
                      <CheckCircle className="h-4 w-4 text-primary" />
                    ) : (
                      <MapPin className="h-4 w-4 text-accent" />
                    )}
                  </div>
                  <div className="flex flex-1 flex-col gap-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-card-foreground truncate max-w-[200px]">
                        {puesto.puesto}
                      </span>
                      <span className="text-xs text-muted-foreground">{puesto.municipio}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 flex-1 rounded-full bg-secondary">
                        <div
                          className={`h-1.5 rounded-full transition-all duration-700 ease-out ${
                            isLow ? "bg-destructive" : isOk ? "bg-primary" : "bg-accent"
                          }`}
                          style={{ width: `${Math.min(pct, 100)}%` }}
                        />
                      </div>
                      <span className="text-xs font-bold tabular-nums text-card-foreground w-12 text-right">
                        {puesto.votantes}/{puesto.meta}
                      </span>
                    </div>
                  </div>
                  {isLow && (
                    <button
                      className="flex-shrink-0 rounded-md bg-destructive/20 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-destructive hover:bg-destructive/30 transition-colors"
                      onClick={() => alert(`Llamar al puesto: ${puesto.puesto} - ${puesto.municipio}`)}
                    >
                      Llamar
                    </button>
                  )}
                </div>
              )
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
