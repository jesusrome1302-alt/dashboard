"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { FileImage, Clock } from "lucide-react"
import type { Voter } from "@/lib/voter-data"

interface RecentVotersProps {
  voters: Voter[]
}

export function RecentVoters({ voters }: RecentVotersProps) {
  const recent = [...voters]
    .filter((v) => v.voto)
    .sort((a, b) => b.horaRegistro.getTime() - a.horaRegistro.getTime())
    .slice(0, 15)

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
          Votantes Recientes
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[380px]">
          <div className="flex flex-col">
            {recent.map((voter) => (
              <div
                key={voter.id}
                className="flex items-center gap-3 border-b border-border px-4 py-3 transition-colors hover:bg-secondary/50"
              >
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <span className="text-xs font-bold">
                    {voter.nombre.split(" ").map(n => n[0]).slice(0, 2).join("")}
                  </span>
                </div>
                <div className="flex flex-1 flex-col gap-0.5">
                  <span className="text-sm font-medium text-card-foreground">{voter.nombre}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-muted-foreground">CC {voter.cedula}</span>
                    <span className="text-[10px] text-muted-foreground">Mesa #{voter.mesa}</span>
                    <span className="text-[10px] font-medium text-primary">{voter.lider}</span>
                  </div>
                </div>
                <div className="flex flex-shrink-0 flex-col items-end gap-1">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span className="text-[10px] tabular-nums">
                      {voter.horaRegistro.toLocaleTimeString("es-CO", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                  {voter.certificadoUrl && (
                    <a
                      href={voter.certificadoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-[10px] text-primary hover:underline"
                    >
                      <FileImage className="h-3 w-3" />
                      <span>Certificado</span>
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
