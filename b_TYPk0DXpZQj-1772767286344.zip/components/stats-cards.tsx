"use client"

import { Users, UserCheck, UserX, TrendingUp } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface StatsCardsProps {
  totalRegistered: number
  totalVoted: number
  votingPercentage: number
  registrosUltimaHora: number
}

export function StatsCards({ totalRegistered, totalVoted, votingPercentage, registrosUltimaHora }: StatsCardsProps) {
  const pendientes = totalRegistered - totalVoted

  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      <Card className="border-border bg-card">
        <CardContent className="flex flex-col gap-2 p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Total Registrados
            </span>
            <Users className="h-4 w-4 text-muted-foreground" />
          </div>
          <span className="text-3xl font-bold text-card-foreground tabular-nums">
            {totalRegistered.toLocaleString("es-CO")}
          </span>
          <span className="text-xs text-muted-foreground">Censo electoral del partido</span>
        </CardContent>
      </Card>

      <Card className="border-border bg-card">
        <CardContent className="flex flex-col gap-2 p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Han Votado
            </span>
            <UserCheck className="h-4 w-4 text-primary" />
          </div>
          <span className="text-3xl font-bold text-primary tabular-nums">
            {totalVoted.toLocaleString("es-CO")}
          </span>
          <div className="flex items-center gap-2">
            <div className="h-1.5 flex-1 rounded-full bg-secondary">
              <div
                className="h-1.5 rounded-full bg-primary transition-all duration-700 ease-out"
                style={{ width: `${votingPercentage}%` }}
              />
            </div>
            <span className="text-xs font-bold text-primary tabular-nums">{votingPercentage.toFixed(1)}%</span>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border bg-card">
        <CardContent className="flex flex-col gap-2 p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Pendientes
            </span>
            <UserX className="h-4 w-4 text-accent" />
          </div>
          <span className="text-3xl font-bold text-accent tabular-nums">
            {pendientes.toLocaleString("es-CO")}
          </span>
          <span className="text-xs text-muted-foreground">
            {(100 - votingPercentage).toFixed(1)}% faltan por votar
          </span>
        </CardContent>
      </Card>

      <Card className="border-border bg-card">
        <CardContent className="flex flex-col gap-2 p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Ritmo / hora
            </span>
            <TrendingUp className="h-4 w-4 text-chart-2" />
          </div>
          <span className="text-3xl font-bold text-card-foreground tabular-nums">
            {registrosUltimaHora}
          </span>
          <span className="text-xs text-muted-foreground">Registros en la ultima hora</span>
        </CardContent>
      </Card>
    </div>
  )
}
