"use client"

import { Card, CardContent } from "@/components/ui/card"

interface VotingProgressProps {
  totalRegistered: number
  totalVoted: number
}

export function VotingProgress({ totalRegistered, totalVoted }: VotingProgressProps) {
  const pct = totalRegistered > 0 ? (totalVoted / totalRegistered) * 100 : 0
  const radius = 80
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (pct / 100) * circumference

  return (
    <Card className="border-border bg-card">
      <CardContent className="flex flex-col items-center gap-4 p-6">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Porcentaje de Votacion
        </span>
        <div className="relative">
          <svg width="200" height="200" viewBox="0 0 200 200">
            <circle
              cx="100"
              cy="100"
              r={radius}
              fill="none"
              stroke="hsl(260 10% 22%)"
              strokeWidth="12"
            />
            <circle
              cx="100"
              cy="100"
              r={radius}
              fill="none"
              stroke="hsl(145 60% 45%)"
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              transform="rotate(-90 100 100)"
              style={{ transition: "stroke-dashoffset 1.5s ease-out" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-4xl font-bold text-card-foreground tabular-nums">
              {pct.toFixed(1)}%
            </span>
            <span className="text-xs text-muted-foreground">completado</span>
          </div>
        </div>
        <div className="flex gap-6 text-center">
          <div>
            <span className="block text-lg font-bold text-primary tabular-nums">{totalVoted}</span>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Votaron</span>
          </div>
          <div className="h-10 w-px bg-border" />
          <div>
            <span className="block text-lg font-bold text-accent tabular-nums">{totalRegistered - totalVoted}</span>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Pendientes</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
