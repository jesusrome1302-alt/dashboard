export interface Voter {
  id: number
  lider: string
  nombre: string
  cedula: string
  municipio: string
  puestoVotacion: string
  direccion: string
  mesa: number
  comuna: number
  voto: boolean
  certificadoUrl?: string
  horaRegistro: Date
}

// Based on real data from the PDF
export const voterData: Voter[] = [
  {
    id: 1, lider: "ADRIANA", nombre: "JORGE ENRIQUE GARCIA", cedula: "13246150",
    municipio: "CUCUTA", puestoVotacion: "COLEGIO SIMON BOLIVAR", direccion: "SAN MARTIN",
    mesa: 2, comuna: 4, voto: true, horaRegistro: new Date("2026-03-05T08:15:00"),
  },
  {
    id: 2, lider: "ADRIANA", nombre: "FRANCISCO CAMARON DE BUITRAGO", cedula: "27681654",
    municipio: "CUCUTA", puestoVotacion: "ESC. MARCO FIDEL SUAREZ", direccion: "SAN LUIS",
    mesa: 6, comuna: 4, voto: true, certificadoUrl: "https://drive.google.com/file/d/1qaU02RuCjp-bRp-aVG5JPAbz7h_w8KJF/view",
    horaRegistro: new Date("2026-03-05T08:32:00"),
  },
  {
    id: 3, lider: "ADRIANA", nombre: "SONIA ESTEFANI OJEDA LUNA", cedula: "60322823",
    municipio: "CUCUTA", puestoVotacion: "IE PABLO CORREA SD MARIA AUXILIADORA", direccion: "ANIVERSARIO I",
    mesa: 12, comuna: 4, voto: true, certificadoUrl: "https://drive.google.com/file/d/1TiNWsfkU2046_R9arpRvQ37-PHpYOsmZ/view",
    horaRegistro: new Date("2026-03-05T08:45:00"),
  },
  {
    id: 4, lider: "ADRIANA", nombre: "FLORENTINO QUINCHOA JACANAMIJOY", cedula: "1004811611",
    municipio: "CUCUTA", puestoVotacion: "COLEGIO SIMON BOLIVAR", direccion: "SAN MARTIN",
    mesa: 11, comuna: 4, voto: true, certificadoUrl: "https://drive.google.com/file/d/1fP8ngnV7ADV3ke8kJ8sGHVtfGlbE3wQP/view",
    horaRegistro: new Date("2026-03-05T09:10:00"),
  },
  {
    id: 5, lider: "BLANCA", nombre: "JORGE ENRIQUE SARMIENTO", cedula: "13227244",
    municipio: "CUCUTA", puestoVotacion: "COL BUENOS AIRES", direccion: "CL. 30 AV. 7 Y 7A BUENOS AIRES",
    mesa: 2, comuna: 7, voto: true, certificadoUrl: "https://drive.google.com/file/d/162dwyTWBEVfvkxzTvjgAgSHX3-rEWvvf/view",
    horaRegistro: new Date("2026-03-05T09:22:00"),
  },
  {
    id: 6, lider: "BLANCA", nombre: "JUAN CARLOS MADURO SARMIENTO", cedula: "13480454",
    municipio: "CUCUTA", puestoVotacion: "COL BUENOS AIRES", direccion: "CL. 30 AV. 7 Y 7A BUENOS AIRES",
    mesa: 3, comuna: 7, voto: true, horaRegistro: new Date("2026-03-05T09:35:00"),
  },
  {
    id: 7, lider: "BLANCA", nombre: "HELENA BAUTISTA", cedula: "27586600",
    municipio: "CUCUTA", puestoVotacion: "COL BUENOS AIRES", direccion: "CL. 30 AV. 7 Y 7A BUENOS AIRES",
    mesa: 4, comuna: 7, voto: true, horaRegistro: new Date("2026-03-05T09:50:00"),
  },
  {
    id: 8, lider: "BLANCA", nombre: "FRANCELINA SANGUINO", cedula: "27638329",
    municipio: "CUCUTA", puestoVotacion: "COL CONCEJO DE CUCUTA", direccion: "AV 5 MZ 7 LT 67 B. TUCUNARE ATALAYA",
    mesa: 2, comuna: 7, voto: true, horaRegistro: new Date("2026-03-05T10:05:00"),
  },
  {
    id: 9, lider: "BLANCA", nombre: "MARLENE MONTANEZ QUINTERO", cedula: "27706114",
    municipio: "CUCUTA", puestoVotacion: "IE PABLO CORREA SD MARIA AUXILIADORA", direccion: "ANIVERSARIO I",
    mesa: 6, comuna: 4, voto: true, horaRegistro: new Date("2026-03-05T10:18:00"),
  },
  {
    id: 10, lider: "BLANCA", nombre: "FLOR DE MARIA SUAREZ CASTILLO", cedula: "28076753",
    municipio: "CUCUTA", puestoVotacion: "PUESTO CABECERA MUNICIPAL", direccion: "V/ OLIMPICA CR 2 CLL 3",
    mesa: 7, comuna: 0, voto: true, horaRegistro: new Date("2026-03-05T10:30:00"),
  },
  {
    id: 11, lider: "BLANCA", nombre: "LEIDY ROPERO", cedula: "37392474",
    municipio: "CUCUTA", puestoVotacion: "COL ANDRES BELLO SEDE LAURA VI", direccion: "AV 13 # 12N-66 BR. CARLOS PIZARRO",
    mesa: 6, comuna: 6, voto: true, horaRegistro: new Date("2026-03-05T10:45:00"),
  },
  {
    id: 12, lider: "BLANCA", nombre: "MAYERLY LILIANA PUENTES", cedula: "37440131",
    municipio: "CUCUTA", puestoVotacion: "COL ANDRES BELLO SEDE LAURA VI", direccion: "AV 13 # 12N-66 BR. CARLOS PIZARRO",
    mesa: 6, comuna: 6, voto: true, horaRegistro: new Date("2026-03-05T11:00:00"),
  },
  {
    id: 13, lider: "BLANCA", nombre: "NANCY ESTHER UZCATEGUI MENESES", cedula: "60303099",
    municipio: "CUCUTA", puestoVotacion: "COL. CARLOS PEREZ ESCALANTE", direccion: "CALLE 13 No. 2 - 26 BARRIO SAN LUIS",
    mesa: 5, comuna: 4, voto: true, horaRegistro: new Date("2026-03-05T11:20:00"),
  },
  {
    id: 14, lider: "BLANCA", nombre: "OSCAR VANEGAS", cedula: "1077872499",
    municipio: "GARZON", puestoVotacion: "CAGUANCITO INST.EDUC.CAGUANCITO", direccion: "CAGUANCITO",
    mesa: 5, comuna: 99, voto: true, horaRegistro: new Date("2026-03-05T11:35:00"),
  },
  {
    id: 15, lider: "BLANCA", nombre: "DIANA K MANOSALVA", cedula: "1090408004",
    municipio: "CUCUTA", puestoVotacion: "UNIVERSIDAD FRANCISCO DE PAULA SANTANDER", direccion: "AV. GRAN COLOMBIA No. 12 E - 96",
    mesa: 28, comuna: 2, voto: true, horaRegistro: new Date("2026-03-05T11:52:00"),
  },
  {
    id: 16, lider: "BLANCA", nombre: "JONATHAN OMANA", cedula: "1090411094",
    municipio: "CARTAGENA", puestoVotacion: "FUNDACION UNIVERSITARIA LOS LIBERTADORES", direccion: "PIE DE LA POPA, CALLE 31 No 19 -51",
    mesa: 17, comuna: 8, voto: true, horaRegistro: new Date("2026-03-05T12:10:00"),
  },
  {
    id: 17, lider: "BLANCA", nombre: "JENNIFER MALDONADO", cedula: "1090421020",
    municipio: "CARTAGENA", puestoVotacion: "FUNDACION UNIVERSITARIA LOS LIBERTADORES", direccion: "PIE DE LA POPA, CALLE 31 No 19 -51",
    mesa: 17, comuna: 8, voto: true, horaRegistro: new Date("2026-03-05T12:25:00"),
  },
  {
    id: 18, lider: "BLANCA", nombre: "ASTRID MALDONADO", cedula: "1090451133",
    municipio: "BOGOTA", puestoVotacion: "CENTRO COMERCIAL PASEO SAN RAFAEL", direccion: "AV CLL 134 No 55 - 30",
    mesa: 50, comuna: 11, voto: true, horaRegistro: new Date("2026-03-05T12:40:00"),
  },
]

// Extended simulated data for a realistic dashboard with more voters
export const totalRegisteredVoters = 1250
export const metaVotosPorMesa: Record<number, number> = {
  2: 45, 3: 40, 4: 38, 5: 42, 6: 50, 7: 35, 11: 40, 12: 45, 17: 30, 28: 55, 50: 60,
}

export interface ComunaData {
  comuna: number
  nombre: string
  votantes: number
  meta: number
}

export const comunasData: ComunaData[] = [
  { comuna: 1, nombre: "Comuna 1 - Centro", votantes: 0, meta: 120 },
  { comuna: 2, nombre: "Comuna 2 - Guaimaral", votantes: 1, meta: 95 },
  { comuna: 3, nombre: "Comuna 3 - Cenabastos", votantes: 0, meta: 110 },
  { comuna: 4, nombre: "Comuna 4 - San Luis", votantes: 5, meta: 140 },
  { comuna: 5, nombre: "Comuna 5 - Libertad", votantes: 0, meta: 100 },
  { comuna: 6, nombre: "Comuna 6 - La Cabrera", votantes: 2, meta: 130 },
  { comuna: 7, nombre: "Comuna 7 - Buenos Aires", votantes: 4, meta: 125 },
  { comuna: 8, nombre: "Comuna 8 - Cartagena", votantes: 2, meta: 90 },
  { comuna: 9, nombre: "Comuna 9 - Sevilla", votantes: 0, meta: 85 },
  { comuna: 10, nombre: "Comuna 10 - El Salado", votantes: 0, meta: 70 },
  { comuna: 11, nombre: "Comuna 11 - Bogota", votantes: 1, meta: 50 },
  { comuna: 99, nombre: "Otras Ciudades", votantes: 1, meta: 35 },
]

export interface PuestoData {
  puesto: string
  municipio: string
  votantes: number
  meta: number
  mesas: number[]
}

export const puestosData: PuestoData[] = [
  { puesto: "COLEGIO SIMON BOLIVAR", municipio: "CUCUTA", votantes: 2, meta: 80, mesas: [2, 11] },
  { puesto: "ESC. MARCO FIDEL SUAREZ", municipio: "CUCUTA", votantes: 1, meta: 60, mesas: [6] },
  { puesto: "IE PABLO CORREA SD MARIA AUXILIADORA", municipio: "CUCUTA", votantes: 2, meta: 90, mesas: [6, 12] },
  { puesto: "COL BUENOS AIRES", municipio: "CUCUTA", votantes: 3, meta: 70, mesas: [2, 3, 4] },
  { puesto: "COL CONCEJO DE CUCUTA", municipio: "CUCUTA", votantes: 1, meta: 55, mesas: [2] },
  { puesto: "PUESTO CABECERA MUNICIPAL", municipio: "CUCUTA", votantes: 1, meta: 40, mesas: [7] },
  { puesto: "COL ANDRES BELLO SEDE LAURA VI", municipio: "CUCUTA", votantes: 2, meta: 65, mesas: [6] },
  { puesto: "COL. CARLOS PEREZ ESCALANTE", municipio: "CUCUTA", votantes: 1, meta: 50, mesas: [5] },
  { puesto: "CAGUANCITO INST.EDUC.CAGUANCITO", municipio: "GARZON", votantes: 1, meta: 30, mesas: [5] },
  { puesto: "UNIV. FRANCISCO DE PAULA SANTANDER", municipio: "CUCUTA", votantes: 1, meta: 85, mesas: [28] },
  { puesto: "FUNDACION UNIV. LOS LIBERTADORES", municipio: "CARTAGENA", votantes: 2, meta: 45, mesas: [17] },
  { puesto: "CC PASEO SAN RAFAEL", municipio: "BOGOTA", votantes: 1, meta: 50, mesas: [50] },
]

export interface HourlyData {
  hora: string
  registros: number
}

export function getHourlyRegistrations(voters: Voter[]): HourlyData[] {
  const hours: HourlyData[] = [
    { hora: "8:00", registros: 0 },
    { hora: "9:00", registros: 0 },
    { hora: "10:00", registros: 0 },
    { hora: "11:00", registros: 0 },
    { hora: "12:00", registros: 0 },
    { hora: "13:00", registros: 0 },
    { hora: "14:00", registros: 0 },
    { hora: "15:00", registros: 0 },
    { hora: "16:00", registros: 0 },
  ]

  voters.forEach((voter) => {
    if (voter.voto) {
      const hour = voter.horaRegistro.getHours()
      const idx = hour - 8
      if (idx >= 0 && idx < hours.length) {
        hours[idx].registros += 1
      }
    }
  })

  return hours
}

// Simulate more voters arriving over time for realism
export function generateSimulatedVoters(baseVoters: Voter[], count: number): Voter[] {
  const nombres = [
    "CARLOS MARTINEZ", "MARIA FERNANDA LOPEZ", "ANDRES FELIPE RUIZ",
    "PATRICIA GOMEZ", "LUIS HERNANDO DIAZ", "CARMEN ROSA VILLAMIZAR",
    "PEDRO ANTONIO SUAREZ", "ROSA ELVIRA CONTRERAS", "MIGUEL ANGEL ORTEGA",
    "SANDRA MILENA PENA", "ALEJANDRO DURAN", "BEATRIZ ELENA MORA",
    "FERNANDO JOSE PLATA", "GLORIA AMPARO CUELLAR", "RAFAEL EDUARDO NIETO",
    "LUZ MARINA ACEVEDO", "DIEGO ARMANDO BLANCO", "NELLY SOFIA RINCON",
    "OSCAR IVAN TORRES", "ANA MARIA CAICEDO", "JOSE DAVID RANGEL",
    "MARTHA CECILIA PEREZ", "RICARDO ALONSO JAIMES", "CLAUDIA PATRICIA ROJAS",
    "HENRY WILLIAM CARVAJAL", "YOLANDA INES SERRANO", "JORGE IVAN MENDOZA",
    "ESPERANZA DEL CARMEN VARGAS", "JULIO CESAR QUINTERO", "ADRIANA LUCIA FLOREZ",
  ]

  const puestos = puestosData
  const comunas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  const lideres = ["ADRIANA", "BLANCA", "CARLOS", "DIANA", "ELENA"]

  const extraVoters: Voter[] = []

  for (let i = 0; i < count; i++) {
    const puesto = puestos[Math.floor(Math.random() * puestos.length)]
    const hour = 8 + Math.floor(Math.random() * 8)
    const minute = Math.floor(Math.random() * 60)

    extraVoters.push({
      id: baseVoters.length + i + 1,
      lider: lideres[Math.floor(Math.random() * lideres.length)],
      nombre: nombres[Math.floor(Math.random() * nombres.length)],
      cedula: String(10000000 + Math.floor(Math.random() * 90000000)),
      municipio: puesto.municipio,
      puestoVotacion: puesto.puesto,
      direccion: "",
      mesa: puesto.mesas[Math.floor(Math.random() * puesto.mesas.length)],
      comuna: comunas[Math.floor(Math.random() * comunas.length)],
      voto: true,
      horaRegistro: new Date(`2026-03-05T${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:00`),
    })
  }

  return [...baseVoters, ...extraVoters]
}
