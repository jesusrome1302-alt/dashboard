"""
Centro de Comando Electoral - Dashboard en Streamlit
=====================================================
Equivalente del dashboard Next.js/React convertido a Python/Streamlit.

Para ejecutar:
1. pip install streamlit pandas plotly
2. streamlit run streamlit_dashboard.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time
import random

# =============================================================================
# CONFIGURACION DE LA PAGINA
# =============================================================================
st.set_page_config(
    page_title="Centro de Comando Electoral",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# =============================================================================
# ESTILOS CSS PERSONALIZADOS
# =============================================================================
st.markdown("""
<style>
    /* Ocultar elementos por defecto de Streamlit */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    
    /* Estilo del header */
    .main-header {
        background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%);
        padding: 1.5rem 2rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
        color: white;
    }
    
    .main-header h1 {
        margin: 0;
        font-size: 1.75rem;
        font-weight: 700;
    }
    
    .main-header p {
        margin: 0.25rem 0 0 0;
        opacity: 0.85;
        font-size: 0.9rem;
    }
    
    /* Cards de metricas */
    .metric-card {
        background: white;
        padding: 1.25rem;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        border: 1px solid #e5e7eb;
    }
    
    .metric-label {
        font-size: 0.8rem;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.5rem;
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        color: #1f2937;
    }
    
    /* Status en vivo */
    .live-indicator {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: rgba(34, 197, 94, 0.1);
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        color: #16a34a;
    }
    
    .live-dot {
        width: 8px;
        height: 8px;
        background: #22c55e;
        border-radius: 50%;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }
    
    /* Countdown */
    .countdown-container {
        background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
        padding: 1rem 1.5rem;
        border-radius: 10px;
        text-align: center;
        border: 1px solid #fbbf24;
    }
    
    .countdown-label {
        font-size: 0.75rem;
        color: #92400e;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .countdown-time {
        font-size: 1.5rem;
        font-weight: 700;
        color: #78350f;
        font-family: monospace;
    }
    
    /* Tablas */
    .dataframe {
        font-size: 0.85rem !important;
    }
    
    /* Progress bar personalizado */
    .progress-container {
        background: #e5e7eb;
        border-radius: 10px;
        height: 12px;
        overflow: hidden;
    }
    
    .progress-bar {
        background: linear-gradient(90deg, #3b82f6 0%, #1d4ed8 100%);
        height: 100%;
        border-radius: 10px;
        transition: width 0.5s ease;
    }
</style>
""", unsafe_allow_html=True)


# =============================================================================
# DATOS (Equivalente a voter-data.ts)
# =============================================================================

# Datos base de votantes
VOTER_DATA_BASE = [
    {"id": 1, "lider": "ADRIANA", "nombre": "JORGE ENRIQUE GARCIA", "cedula": "13246150",
     "municipio": "CUCUTA", "puesto": "COLEGIO SIMON BOLIVAR", "mesa": 2, "comuna": 4,
     "voto": True, "hora": "08:15"},
    {"id": 2, "lider": "ADRIANA", "nombre": "FRANCISCO CAMARON DE BUITRAGO", "cedula": "27681654",
     "municipio": "CUCUTA", "puesto": "ESC. MARCO FIDEL SUAREZ", "mesa": 6, "comuna": 4,
     "voto": True, "hora": "08:32"},
    {"id": 3, "lider": "ADRIANA", "nombre": "SONIA ESTEFANI OJEDA LUNA", "cedula": "60322823",
     "municipio": "CUCUTA", "puesto": "IE PABLO CORREA SD MARIA AUXILIADORA", "mesa": 12, "comuna": 4,
     "voto": True, "hora": "08:45"},
    {"id": 4, "lider": "ADRIANA", "nombre": "FLORENTINO QUINCHOA JACANAMIJOY", "cedula": "1004811611",
     "municipio": "CUCUTA", "puesto": "COLEGIO SIMON BOLIVAR", "mesa": 11, "comuna": 4,
     "voto": True, "hora": "09:10"},
    {"id": 5, "lider": "BLANCA", "nombre": "JORGE ENRIQUE SARMIENTO", "cedula": "13227244",
     "municipio": "CUCUTA", "puesto": "COL BUENOS AIRES", "mesa": 2, "comuna": 7,
     "voto": True, "hora": "09:22"},
    {"id": 6, "lider": "BLANCA", "nombre": "JUAN CARLOS MADURO SARMIENTO", "cedula": "13480454",
     "municipio": "CUCUTA", "puesto": "COL BUENOS AIRES", "mesa": 3, "comuna": 7,
     "voto": True, "hora": "09:35"},
    {"id": 7, "lider": "BLANCA", "nombre": "HELENA BAUTISTA", "cedula": "27586600",
     "municipio": "CUCUTA", "puesto": "COL BUENOS AIRES", "mesa": 4, "comuna": 7,
     "voto": True, "hora": "09:50"},
    {"id": 8, "lider": "BLANCA", "nombre": "FRANCELINA SANGUINO", "cedula": "27638329",
     "municipio": "CUCUTA", "puesto": "COL CONCEJO DE CUCUTA", "mesa": 2, "comuna": 7,
     "voto": True, "hora": "10:05"},
    {"id": 9, "lider": "BLANCA", "nombre": "MARLENE MONTANEZ QUINTERO", "cedula": "27706114",
     "municipio": "CUCUTA", "puesto": "IE PABLO CORREA SD MARIA AUXILIADORA", "mesa": 6, "comuna": 4,
     "voto": True, "hora": "10:18"},
    {"id": 10, "lider": "BLANCA", "nombre": "FLOR DE MARIA SUAREZ CASTILLO", "cedula": "28076753",
     "municipio": "CUCUTA", "puesto": "PUESTO CABECERA MUNICIPAL", "mesa": 7, "comuna": 0,
     "voto": True, "hora": "10:30"},
    {"id": 11, "lider": "BLANCA", "nombre": "LEIDY ROPERO", "cedula": "37392474",
     "municipio": "CUCUTA", "puesto": "COL ANDRES BELLO SEDE LAURA VI", "mesa": 6, "comuna": 6,
     "voto": True, "hora": "10:45"},
    {"id": 12, "lider": "BLANCA", "nombre": "MAYERLY LILIANA PUENTES", "cedula": "37440131",
     "municipio": "CUCUTA", "puesto": "COL ANDRES BELLO SEDE LAURA VI", "mesa": 6, "comuna": 6,
     "voto": True, "hora": "11:00"},
    {"id": 13, "lider": "BLANCA", "nombre": "NANCY ESTHER UZCATEGUI MENESES", "cedula": "60303099",
     "municipio": "CUCUTA", "puesto": "COL. CARLOS PEREZ ESCALANTE", "mesa": 5, "comuna": 4,
     "voto": True, "hora": "11:20"},
    {"id": 14, "lider": "BLANCA", "nombre": "OSCAR VANEGAS", "cedula": "1077872499",
     "municipio": "GARZON", "puesto": "CAGUANCITO INST.EDUC.CAGUANCITO", "mesa": 5, "comuna": 99,
     "voto": True, "hora": "11:35"},
    {"id": 15, "lider": "BLANCA", "nombre": "DIANA K MANOSALVA", "cedula": "1090408004",
     "municipio": "CUCUTA", "puesto": "UNIV. FRANCISCO DE PAULA SANTANDER", "mesa": 28, "comuna": 2,
     "voto": True, "hora": "11:52"},
    {"id": 16, "lider": "BLANCA", "nombre": "JONATHAN OMANA", "cedula": "1090411094",
     "municipio": "CARTAGENA", "puesto": "FUNDACION UNIV. LOS LIBERTADORES", "mesa": 17, "comuna": 8,
     "voto": True, "hora": "12:10"},
    {"id": 17, "lider": "BLANCA", "nombre": "JENNIFER MALDONADO", "cedula": "1090421020",
     "municipio": "CARTAGENA", "puesto": "FUNDACION UNIV. LOS LIBERTADORES", "mesa": 17, "comuna": 8,
     "voto": True, "hora": "12:25"},
    {"id": 18, "lider": "BLANCA", "nombre": "ASTRID MALDONADO", "cedula": "1090451133",
     "municipio": "BOGOTA", "puesto": "CC PASEO SAN RAFAEL", "mesa": 50, "comuna": 11,
     "voto": True, "hora": "12:40"},
]

# Datos de comunas
COMUNAS_DATA = [
    {"comuna": 1, "nombre": "Centro", "meta": 120},
    {"comuna": 2, "nombre": "Guaimaral", "meta": 95},
    {"comuna": 3, "nombre": "Cenabastos", "meta": 110},
    {"comuna": 4, "nombre": "San Luis", "meta": 140},
    {"comuna": 5, "nombre": "Libertad", "meta": 100},
    {"comuna": 6, "nombre": "La Cabrera", "meta": 130},
    {"comuna": 7, "nombre": "Buenos Aires", "meta": 125},
    {"comuna": 8, "nombre": "Cartagena", "meta": 90},
    {"comuna": 9, "nombre": "Sevilla", "meta": 85},
    {"comuna": 10, "nombre": "El Salado", "meta": 70},
    {"comuna": 11, "nombre": "Bogota", "meta": 50},
    {"comuna": 99, "nombre": "Otras Ciudades", "meta": 35},
]

# Datos de puestos de votacion
PUESTOS_DATA = [
    {"puesto": "COLEGIO SIMON BOLIVAR", "municipio": "CUCUTA", "meta": 80, "mesas": [2, 11]},
    {"puesto": "ESC. MARCO FIDEL SUAREZ", "municipio": "CUCUTA", "meta": 60, "mesas": [6]},
    {"puesto": "IE PABLO CORREA SD MARIA AUXILIADORA", "municipio": "CUCUTA", "meta": 90, "mesas": [6, 12]},
    {"puesto": "COL BUENOS AIRES", "municipio": "CUCUTA", "meta": 70, "mesas": [2, 3, 4]},
    {"puesto": "COL CONCEJO DE CUCUTA", "municipio": "CUCUTA", "meta": 55, "mesas": [2]},
    {"puesto": "PUESTO CABECERA MUNICIPAL", "municipio": "CUCUTA", "meta": 40, "mesas": [7]},
    {"puesto": "COL ANDRES BELLO SEDE LAURA VI", "municipio": "CUCUTA", "meta": 65, "mesas": [6]},
    {"puesto": "COL. CARLOS PEREZ ESCALANTE", "municipio": "CUCUTA", "meta": 50, "mesas": [5]},
    {"puesto": "CAGUANCITO INST.EDUC.CAGUANCITO", "municipio": "GARZON", "meta": 30, "mesas": [5]},
    {"puesto": "UNIV. FRANCISCO DE PAULA SANTANDER", "municipio": "CUCUTA", "meta": 85, "mesas": [28]},
    {"puesto": "FUNDACION UNIV. LOS LIBERTADORES", "municipio": "CARTAGENA", "meta": 45, "mesas": [17]},
    {"puesto": "CC PASEO SAN RAFAEL", "municipio": "BOGOTA", "meta": 50, "mesas": [50]},
]

TOTAL_REGISTRADOS = 1250

NOMBRES_SIMULADOS = [
    "CARLOS MARTINEZ", "MARIA FERNANDA LOPEZ", "ANDRES FELIPE RUIZ",
    "PATRICIA GOMEZ", "LUIS HERNANDO DIAZ", "CARMEN ROSA VILLAMIZAR",
    "PEDRO ANTONIO SUAREZ", "ROSA ELVIRA CONTRERAS", "MIGUEL ANGEL ORTEGA",
    "SANDRA MILENA PENA", "ALEJANDRO DURAN", "BEATRIZ ELENA MORA",
    "FERNANDO JOSE PLATA", "GLORIA AMPARO CUELLAR", "RAFAEL EDUARDO NIETO",
    "LUZ MARINA ACEVEDO", "DIEGO ARMANDO BLANCO", "NELLY SOFIA RINCON",
    "OSCAR IVAN TORRES", "ANA MARIA CAICEDO", "JOSE DAVID RANGEL",
    "MARTHA CECILIA PEREZ", "RICARDO ALONSO JAIMES", "CLAUDIA PATRICIA ROJAS",
]

LIDERES = ["ADRIANA", "BLANCA", "CARLOS", "DIANA", "ELENA"]


# =============================================================================
# FUNCIONES AUXILIARES
# =============================================================================

def generar_votantes_simulados(base_voters: list, cantidad: int) -> pd.DataFrame:
    """Genera votantes simulados adicionales para el dashboard."""
    extra_voters = []
    
    for i in range(cantidad):
        puesto = random.choice(PUESTOS_DATA)
        hora = random.randint(8, 15)
        minuto = random.randint(0, 59)
        
        extra_voters.append({
            "id": len(base_voters) + i + 1,
            "lider": random.choice(LIDERES),
            "nombre": random.choice(NOMBRES_SIMULADOS),
            "cedula": str(random.randint(10000000, 99999999)),
            "municipio": puesto["municipio"],
            "puesto": puesto["puesto"],
            "mesa": random.choice(puesto["mesas"]),
            "comuna": random.randint(1, 10),
            "voto": True,
            "hora": f"{hora:02d}:{minuto:02d}",
        })
    
    all_voters = base_voters + extra_voters
    return pd.DataFrame(all_voters)


def calcular_registros_por_hora(df: pd.DataFrame) -> pd.DataFrame:
    """Calcula los registros por hora."""
    df_copy = df.copy()
    df_copy["hora_int"] = df_copy["hora"].apply(lambda x: int(x.split(":")[0]))
    
    horas = list(range(8, 17))
    registros = []
    
    for h in horas:
        count = len(df_copy[(df_copy["hora_int"] == h) & (df_copy["voto"] == True)])
        registros.append({"hora": f"{h}:00", "registros": count})
    
    return pd.DataFrame(registros)


def calcular_votos_por_comuna(df: pd.DataFrame) -> pd.DataFrame:
    """Calcula votos por comuna."""
    votos = df[df["voto"] == True].groupby("comuna").size().reset_index(name="votantes")
    
    comunas_df = pd.DataFrame(COMUNAS_DATA)
    result = comunas_df.merge(votos, on="comuna", how="left")
    result["votantes"] = result["votantes"].fillna(0).astype(int)
    result["porcentaje"] = (result["votantes"] / result["meta"] * 100).round(1)
    
    return result


def calcular_votos_por_puesto(df: pd.DataFrame) -> pd.DataFrame:
    """Calcula votos por puesto de votacion."""
    votos = df[df["voto"] == True].groupby("puesto").size().reset_index(name="votantes")
    
    puestos_df = pd.DataFrame(PUESTOS_DATA)[["puesto", "municipio", "meta"]]
    result = puestos_df.merge(votos, on="puesto", how="left")
    result["votantes"] = result["votantes"].fillna(0).astype(int)
    result["porcentaje"] = (result["votantes"] / result["meta"] * 100).round(1)
    
    return result.sort_values("votantes", ascending=False)


def calcular_votos_por_mesa(df: pd.DataFrame) -> pd.DataFrame:
    """Calcula votos por mesa."""
    votos = df[df["voto"] == True].groupby(["mesa", "puesto"]).size().reset_index(name="votantes")
    votos["meta"] = 40  # Meta por defecto
    votos["porcentaje"] = (votos["votantes"] / votos["meta"] * 100).round(1)
    
    return votos.sort_values("votantes", ascending=False)


def obtener_tiempo_restante() -> tuple:
    """Calcula el tiempo restante hasta el cierre (4:00 PM)."""
    ahora = datetime.now()
    cierre = ahora.replace(hour=16, minute=0, second=0, microsecond=0)
    
    if ahora >= cierre:
        return 0, 0, 0
    
    diferencia = cierre - ahora
    horas = diferencia.seconds // 3600
    minutos = (diferencia.seconds % 3600) // 60
    segundos = diferencia.seconds % 60
    
    return horas, minutos, segundos


# =============================================================================
# INICIALIZAR ESTADO DE LA SESION
# =============================================================================

if "voters_df" not in st.session_state:
    st.session_state.voters_df = generar_votantes_simulados(VOTER_DATA_BASE, 180)
    st.session_state.last_update = datetime.now()
    st.session_state.is_live = True


# =============================================================================
# HEADER
# =============================================================================

col_header, col_countdown, col_status = st.columns([3, 1.5, 1])

with col_header:
    st.markdown("""
    <div class="main-header">
        <h1>Centro de Comando Electoral</h1>
        <p>Monitoreo en tiempo real de la jornada electoral</p>
    </div>
    """, unsafe_allow_html=True)

with col_countdown:
    horas, minutos, segundos = obtener_tiempo_restante()
    st.markdown(f"""
    <div class="countdown-container">
        <div class="countdown-label">Tiempo para el cierre</div>
        <div class="countdown-time">{horas:02d}:{minutos:02d}:{segundos:02d}</div>
    </div>
    """, unsafe_allow_html=True)

with col_status:
    col_live, col_refresh = st.columns(2)
    with col_live:
        st.session_state.is_live = st.checkbox("EN VIVO", value=st.session_state.is_live)
    with col_refresh:
        if st.button("Actualizar"):
            # Agregar un nuevo votante simulado
            new_voter = {
                "id": len(st.session_state.voters_df) + 1,
                "lider": random.choice(LIDERES),
                "nombre": random.choice(NOMBRES_SIMULADOS),
                "cedula": str(random.randint(10000000, 99999999)),
                "municipio": random.choice(PUESTOS_DATA)["municipio"],
                "puesto": random.choice(PUESTOS_DATA)["puesto"],
                "mesa": random.randint(1, 50),
                "comuna": random.randint(1, 10),
                "voto": True,
                "hora": datetime.now().strftime("%H:%M"),
            }
            st.session_state.voters_df = pd.concat([
                st.session_state.voters_df, 
                pd.DataFrame([new_voter])
            ], ignore_index=True)
            st.session_state.last_update = datetime.now()


# =============================================================================
# METRICAS PRINCIPALES (StatsCards)
# =============================================================================

st.markdown("### Resumen General")

df = st.session_state.voters_df
total_votaron = len(df[df["voto"] == True])
porcentaje = (total_votaron / TOTAL_REGISTRADOS) * 100

# Calcular registros ultima hora
ahora = datetime.now()
hora_actual = ahora.hour
df_temp = df.copy()
df_temp["hora_int"] = df_temp["hora"].apply(lambda x: int(x.split(":")[0]))
registros_ultima_hora = len(df_temp[(df_temp["hora_int"] == hora_actual) & (df_temp["voto"] == True)])

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        label="Votantes Registrados",
        value=f"{TOTAL_REGISTRADOS:,}",
        delta=None
    )

with col2:
    st.metric(
        label="Votos Confirmados",
        value=f"{total_votaron:,}",
        delta=f"+{registros_ultima_hora} esta hora"
    )

with col3:
    st.metric(
        label="Participacion",
        value=f"{porcentaje:.1f}%",
        delta=f"{porcentaje - 10:.1f}% vs meta" if porcentaje > 10 else None
    )

with col4:
    st.metric(
        label="Ultima Hora",
        value=f"{registros_ultima_hora}",
        delta=None
    )


# =============================================================================
# GRAFICOS PRINCIPALES
# =============================================================================

st.markdown("---")

col_chart1, col_chart2 = st.columns([2, 1])

with col_chart1:
    st.markdown("### Votos por Comuna")
    
    comunas_df = calcular_votos_por_comuna(df)
    
    fig_comunas = px.bar(
        comunas_df,
        x="nombre",
        y="votantes",
        color="porcentaje",
        color_continuous_scale=["#fecaca", "#22c55e"],
        labels={"nombre": "Comuna", "votantes": "Votos", "porcentaje": "% Meta"},
        text="votantes"
    )
    fig_comunas.update_traces(textposition="outside")
    fig_comunas.update_layout(
        xaxis_tickangle=-45,
        height=400,
        showlegend=False,
        margin=dict(l=20, r=20, t=40, b=80)
    )
    st.plotly_chart(fig_comunas, use_container_width=True)

with col_chart2:
    st.markdown("### Progreso de Votacion")
    
    # Gauge chart para progreso
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=porcentaje,
        domain={"x": [0, 1], "y": [0, 1]},
        title={"text": "Participacion", "font": {"size": 16}},
        delta={"reference": 50, "increasing": {"color": "#22c55e"}},
        gauge={
            "axis": {"range": [0, 100], "tickwidth": 1},
            "bar": {"color": "#3b82f6"},
            "bgcolor": "white",
            "borderwidth": 2,
            "bordercolor": "#e5e7eb",
            "steps": [
                {"range": [0, 30], "color": "#fecaca"},
                {"range": [30, 60], "color": "#fef08a"},
                {"range": [60, 100], "color": "#bbf7d0"}
            ],
            "threshold": {
                "line": {"color": "#dc2626", "width": 4},
                "thickness": 0.75,
                "value": 50
            }
        }
    ))
    fig_gauge.update_layout(height=300, margin=dict(l=20, r=20, t=60, b=20))
    st.plotly_chart(fig_gauge, use_container_width=True)
    
    # Info adicional
    st.info(f"**{total_votaron:,}** de **{TOTAL_REGISTRADOS:,}** votantes han ejercido su derecho")


# =============================================================================
# GRAFICOS SECUNDARIOS
# =============================================================================

st.markdown("---")

col_hourly, col_puestos = st.columns(2)

with col_hourly:
    st.markdown("### Registros por Hora")
    
    hourly_df = calcular_registros_por_hora(df)
    
    fig_hourly = px.area(
        hourly_df,
        x="hora",
        y="registros",
        labels={"hora": "Hora", "registros": "Registros"},
        color_discrete_sequence=["#3b82f6"]
    )
    fig_hourly.update_layout(
        height=350,
        margin=dict(l=20, r=20, t=40, b=40)
    )
    st.plotly_chart(fig_hourly, use_container_width=True)

with col_puestos:
    st.markdown("### Top Puestos de Votacion")
    
    puestos_df = calcular_votos_por_puesto(df).head(8)
    
    fig_puestos = px.bar(
        puestos_df,
        y="puesto",
        x="votantes",
        orientation="h",
        color="porcentaje",
        color_continuous_scale=["#fecaca", "#22c55e"],
        labels={"puesto": "Puesto", "votantes": "Votos", "porcentaje": "% Meta"},
        text="votantes"
    )
    fig_puestos.update_traces(textposition="outside")
    fig_puestos.update_layout(
        height=350,
        yaxis={"categoryorder": "total ascending"},
        margin=dict(l=20, r=60, t=40, b=40),
        showlegend=False
    )
    st.plotly_chart(fig_puestos, use_container_width=True)


# =============================================================================
# TABLAS DE DATOS
# =============================================================================

st.markdown("---")

col_mesa, col_recent = st.columns(2)

with col_mesa:
    st.markdown("### Votos por Mesa")
    
    mesa_df = calcular_votos_por_mesa(df).head(10)
    mesa_display = mesa_df[["mesa", "puesto", "votantes", "meta", "porcentaje"]].copy()
    mesa_display.columns = ["Mesa", "Puesto", "Votantes", "Meta", "% Avance"]
    
    st.dataframe(
        mesa_display,
        use_container_width=True,
        hide_index=True,
        column_config={
            "% Avance": st.column_config.ProgressColumn(
                "% Avance",
                min_value=0,
                max_value=100,
                format="%.1f%%"
            )
        }
    )

with col_recent:
    st.markdown("### Votantes Recientes")
    
    recent_df = df.tail(10).sort_values("id", ascending=False)
    recent_display = recent_df[["nombre", "puesto", "mesa", "hora", "lider"]].copy()
    recent_display.columns = ["Nombre", "Puesto", "Mesa", "Hora", "Lider"]
    
    st.dataframe(
        recent_display,
        use_container_width=True,
        hide_index=True
    )


# =============================================================================
# FOOTER
# =============================================================================

st.markdown("---")

st.markdown(f"""
<div style="text-align: center; color: #6b7280; font-size: 0.85rem; padding: 1rem;">
    Centro de Comando Electoral &middot; 
    Ultima actualizacion: {st.session_state.last_update.strftime("%H:%M:%S")} &middot; 
    Jornada Electoral 2026
</div>
""", unsafe_allow_html=True)


# =============================================================================
# AUTO-REFRESH (si esta en modo EN VIVO)
# =============================================================================

if st.session_state.is_live:
    time.sleep(5)
    # Agregar nuevo votante aleatorio
    new_voter = {
        "id": len(st.session_state.voters_df) + 1,
        "lider": random.choice(LIDERES),
        "nombre": random.choice(NOMBRES_SIMULADOS),
        "cedula": str(random.randint(10000000, 99999999)),
        "municipio": random.choice(PUESTOS_DATA)["municipio"],
        "puesto": random.choice(PUESTOS_DATA)["puesto"],
        "mesa": random.randint(1, 50),
        "comuna": random.randint(1, 10),
        "voto": True,
        "hora": datetime.now().strftime("%H:%M"),
    }
    st.session_state.voters_df = pd.concat([
        st.session_state.voters_df, 
        pd.DataFrame([new_voter])
    ], ignore_index=True)
    st.session_state.last_update = datetime.now()
    st.rerun()
